package com.example.smartiot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartiotApplicationTests {

    @Test
    void contextLoads() {
    }

}
